"""اتصال حساب تلگرام کاربر به سلف (ورود با شماره + کد + رمز دومرحله‌ای).

نکته‌های امنیتی:
- کد ورود فقط با دکمه‌های عددی وارد می‌شه (اگه کد توی چت تایپ بشه، تلگرام خودش اون کد رو باطل می‌کنه).
- رمز دومرحله‌ای فقط برای همون یک ورود استفاده می‌شه، فوراً پیامش پاک می‌شه و هیچ‌جا ذخیره یا لاگ نمی‌شه.
- شماره، کد و رمز هیچ‌وقت وارد لاگ نمی‌شن.
- سشن نهایی رمزنگاری‌شده ذخیره می‌شه (services/accounts.py).
- وضعیت ورودهای در حال انجام توی حافظه‌ی همین پردازشه؛ برای همین ربات باید روی یک نسخه (replica) اجرا بشه.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.types import CallbackQuery, Message
from telethon import TelegramClient
from telethon.errors import (
    FloodWaitError,
    PasswordHashInvalidError,
    PhoneCodeEmptyError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    PhoneNumberBannedError,
    PhoneNumberFloodError,
    PhoneNumberInvalidError,
    RPCError,
    SessionPasswordNeededError,
)
from telethon.sessions import StringSession

from . import keyboards as K
from . import texts as T
from .cache import hit
from .config import LOGIN_IDLE_SECONDS, MAX_PENDING_LOGINS, Settings
from .crypto import Vault
from .keyboards import LoginKey
from .services.accounts import save_account
from .utils import utcnow

log = logging.getLogger(__name__)

MAX_WRONG_CODES = 5
MAX_WRONG_PASSWORDS = 3


@dataclass
class LoginCtx:
    user_id: int
    chat_id: int
    stage: str = "phone"  # phone | connecting | code | password
    msg_ids: list[int] = field(default_factory=list)
    last: float = field(default_factory=time.monotonic)
    client: TelegramClient | None = None
    phone: str | None = None
    phone_hash: str | None = None
    code_len: int = 5
    info: str = ""
    digits: list[str] = field(default_factory=list)
    panel_msg_id: int | None = None
    wrong_codes: int = 0
    wrong_passwords: int = 0
    menu_restored: bool = False
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    watcher: asyncio.Task | None = None


class LoginManager:
    def __init__(self, bot: Bot, db, redis, settings: Settings, vault: Vault) -> None:
        self.bot, self.db, self.redis, self.settings, self.vault = bot, db, redis, settings, vault
        self._ctx: dict[int, LoginCtx] = {}

    # ------------------------------------------------------------ ابزارهای داخلی
    def get(self, user_id: int) -> LoginCtx | None:
        return self._ctx.get(user_id)

    @staticmethod
    def _touch(ctx: LoginCtx) -> None:
        ctx.last = time.monotonic()

    async def _send(self, ctx: LoginCtx, text: str, **kw) -> Message:
        m = await self.bot.send_message(ctx.chat_id, text, **kw)
        ctx.msg_ids.append(m.message_id)
        return m

    async def _delete(self, chat_id: int, ids: list[int]) -> None:
        for i in range(0, len(ids), 100):
            chunk = ids[i : i + 100]
            try:
                await self.bot.delete_messages(chat_id, chunk)
            except TelegramAPIError:
                for mid in chunk:
                    try:
                        await self.bot.delete_message(chat_id, mid)
                    except TelegramAPIError:
                        pass

    async def _edit(self, ctx: LoginCtx, text: str, kb) -> None:
        if ctx.panel_msg_id is None:
            return
        try:
            await self.bot.edit_message_text(text, chat_id=ctx.chat_id, message_id=ctx.panel_msg_id, reply_markup=kb)
        except TelegramBadRequest as e:
            if "not modified" not in str(e):
                log.warning("login panel edit failed: %s", type(e).__name__)
        except TelegramAPIError:
            pass  # مثلاً محدودیت سرعت ویرایش؛ پیام با کلیک بعدی به‌روز می‌شه

    async def _restore_menu(self, chat_id: int) -> None:
        """کیبورد «ارسال شماره» رو با منوی اصلی عوض می‌کنه (پیام موقت می‌فرسته و پاکش می‌کنه)."""
        try:
            m = await self.bot.send_message(chat_id, "🏠", reply_markup=K.main_menu())
            await self.bot.delete_message(chat_id, m.message_id)
        except TelegramAPIError:
            pass

    async def _close(self, ctx: LoginCtx) -> None:
        if self._ctx.get(ctx.user_id) is ctx:
            self._ctx.pop(ctx.user_id, None)
        if ctx.watcher and ctx.watcher is not asyncio.current_task():
            ctx.watcher.cancel()
        client, ctx.client = ctx.client, None
        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                pass
        ctx.digits.clear()
        ctx.phone_hash = None

    async def _finish(
        self, ctx: LoginCtx, text: str | None = None, *, inline_back: bool = False, restore_menu: bool = True
    ) -> None:
        """همه‌ی پیام‌های این ورود پاک می‌شن و (اگه متنی داده شده باشه) همون متن فرستاده می‌شه."""
        ids, ctx.msg_ids = ctx.msg_ids[:], []
        await self._delete(ctx.chat_id, ids)
        await self._close(ctx)
        if restore_menu and not ctx.menu_restored:
            await self._restore_menu(ctx.chat_id)
        if text:
            try:
                await self.bot.send_message(ctx.chat_id, text, reply_markup=K.back_home() if inline_back else None)
            except TelegramAPIError:
                pass

    async def _watch(self, ctx: LoginCtx) -> None:
        try:
            while True:
                remaining = ctx.last + LOGIN_IDLE_SECONDS - time.monotonic()
                if remaining > 0:
                    await asyncio.sleep(remaining)
                    continue
                async with ctx.lock:
                    if self._ctx.get(ctx.user_id) is not ctx:
                        return
                    if ctx.last + LOGIN_IDLE_SECONDS - time.monotonic() > 0:
                        continue
                    await self._finish(ctx, T.LOGIN_TIMEOUT, inline_back=True)
                    return
        except asyncio.CancelledError:
            pass
        except Exception:
            log.exception("login watcher error")

    # ------------------------------------------------------------ شروع و لغو
    async def start(self, chat_id: int, user_id: int, note: str = "", extra_delete: list[int] | None = None) -> None:
        old = self._ctx.get(user_id)
        if old is not None:
            async with old.lock:
                await self._finish(old, restore_menu=False)
        if extra_delete:
            await self._delete(chat_id, extra_delete)
        if len(self._ctx) >= MAX_PENDING_LOGINS:
            await self.bot.send_message(chat_id, T.LOGIN_BUSY)
            return
        ctx = LoginCtx(user_id=user_id, chat_id=chat_id)
        self._ctx[user_id] = ctx
        text = T.CONNECT_PROMPT + (f"\n\n{note}" if note else "")
        await self._send(ctx, text, reply_markup=K.phone_request())
        ctx.watcher = asyncio.create_task(self._watch(ctx))

    async def restart(self, message: Message, note: str) -> None:
        await self.start(message.chat.id, message.from_user.id, note, extra_delete=[message.message_id])

    async def cancel(self, cb: CallbackQuery) -> None:
        ctx = self._ctx.get(cb.from_user.id)
        if ctx is None:
            await cb.answer(T.LOGIN_STALE)
            return
        async with ctx.lock:
            if self._ctx.get(ctx.user_id) is ctx:
                await self._finish(ctx)
        await cb.answer()

    async def close_all(self) -> None:
        for ctx in list(self._ctx.values()):
            await self._close(ctx)

    # ------------------------------------------------------------ مرحله‌ی شماره
    async def submit_phone(self, message: Message, phone: str) -> None:
        uid = message.from_user.id
        ctx = self._ctx.get(uid)
        if ctx is None:
            return
        async with ctx.lock:
            if self._ctx.get(uid) is not ctx or ctx.stage != "phone":
                return
            self._touch(ctx)

            # محدودیت درخواست کد: جلوی فلود تلگرام (و بلاک شدن کلید API) رو می‌گیره
            phone_key = hashlib.sha256(phone.encode()).hexdigest()[:24]
            ok_user = await hit(self.redis, f"lc:u:{uid}", limit=5, window=3600)
            ok_phone = await hit(self.redis, f"lc:p:{phone_key}", limit=3, window=3600)
            if not (ok_user and ok_phone):
                ctx.msg_ids.append(message.message_id)
                await self._finish(ctx, T.LOGIN_RATE, inline_back=True)
                return

            ctx.stage = "connecting"
            ctx.phone = phone
            # پیام جدید می‌فرسته (با منوی اصلی)، بعد پیام قبلی و شماره‌ی کاربر رو پاک می‌کنه
            old_ids = ctx.msg_ids[:] + [message.message_id]
            ctx.msg_ids = []
            m = await self._send(ctx, T.CONNECTING, reply_markup=K.main_menu())
            ctx.menu_restored = True
            ctx.panel_msg_id = m.message_id
            await self._delete(ctx.chat_id, old_ids)

            client = TelegramClient(
                StringSession(),
                self.settings.telegram_api_id,
                self.settings.telegram_api_hash,
                device_model="Self Assistant",
                system_version="Server",
                app_version="1.0",
            )
            ctx.client = client
            try:
                await client.connect()
                sent = await client.send_code_request(phone)
            except PhoneNumberInvalidError:
                await self._finish(ctx)
                await self.start(ctx.chat_id, uid, T.NOTE_BAD_PHONE)
                return
            except PhoneNumberBannedError:
                await self._finish(ctx, T.LOGIN_BANNED, inline_back=True)
                return
            except FloodWaitError as e:
                await self._finish(ctx, T.login_flood(int(e.seconds)), inline_back=True)
                return
            except (PhoneNumberFloodError, RPCError) as e:
                log.warning("send_code failed: %s", type(e).__name__)
                await self._finish(ctx, T.LOGIN_ERROR, inline_back=True)
                return
            except Exception:
                log.exception("send_code unexpected error")
                await self._finish(ctx, T.LOGIN_ERROR, inline_back=True)
                return

            code_type = type(sent.type).__name__
            kind = {"SentCodeTypeApp": "app", "SentCodeTypeSms": "sms", "SentCodeTypeCall": "call"}.get(code_type, "other")
            ctx.code_len = int(getattr(sent.type, "length", 5) or 5)
            ctx.phone_hash = sent.phone_code_hash
            ctx.info = T.code_info(kind, has_alt=sent.next_type is not None)
            ctx.stage = "code"
            self._touch(ctx)
            await self._edit(ctx, T.code_panel(ctx.info, 0, ctx.code_len), K.keypad())

    # ------------------------------------------------------------ مرحله‌ی کد
    async def press(self, cb: CallbackQuery, data: LoginKey) -> None:
        uid = cb.from_user.id
        ctx = self._ctx.get(uid)
        msg_ok = isinstance(cb.message, Message)
        if ctx is None or not msg_ok or cb.message.message_id != ctx.panel_msg_id or ctx.stage not in ("code", "password"):
            await cb.answer(T.LOGIN_STALE, show_alert=True)
            return
        if data.act == "x":
            await self.cancel(cb)
            return
        if ctx.stage != "code":
            await cb.answer()
            return

        async with ctx.lock:
            if self._ctx.get(uid) is not ctx or ctx.stage != "code":
                await cb.answer(T.LOGIN_STALE, show_alert=True)
                return
            self._touch(ctx)

            if data.act == "d":
                if data.d.isdigit() and len(data.d) == 1 and len(ctx.digits) < ctx.code_len:
                    ctx.digits.append(data.d)
            elif data.act == "b":
                if ctx.digits:
                    ctx.digits.pop()
            elif data.act == "c":
                ctx.digits.clear()
            elif data.act == "ok":
                await self._verify_code(cb, ctx)
                return
            await cb.answer()
            await self._edit(ctx, T.code_panel(ctx.info, len(ctx.digits), ctx.code_len), K.keypad())

    async def _verify_code(self, cb: CallbackQuery, ctx: LoginCtx) -> None:
        if len(ctx.digits) != ctx.code_len:
            await cb.answer(f"{T.CODE_INCOMPLETE} ({len(ctx.digits)} از {ctx.code_len})", show_alert=True)
            return
        code = "".join(ctx.digits)
        try:
            await ctx.client.sign_in(phone=ctx.phone, code=code, phone_code_hash=ctx.phone_hash)
        except SessionPasswordNeededError:
            ctx.stage = "password"
            ctx.digits.clear()
            await cb.answer()
            await self._edit(ctx, T.password_prompt(), K.cancel_only())
            return
        except (PhoneCodeInvalidError, PhoneCodeEmptyError):
            ctx.wrong_codes += 1
            ctx.digits.clear()
            if ctx.wrong_codes >= MAX_WRONG_CODES:
                await cb.answer()
                await self._finish(ctx, T.LOGIN_TOO_MANY_CODES, inline_back=True)
                return
            await cb.answer(T.CODE_WRONG, show_alert=True)
            await self._edit(ctx, T.code_panel(ctx.info, 0, ctx.code_len), K.keypad())
            return
        except PhoneCodeExpiredError:
            await cb.answer()
            await self._finish(ctx, T.LOGIN_CODE_EXPIRED, inline_back=True)
            return
        except FloodWaitError as e:
            await cb.answer()
            await self._finish(ctx, T.login_flood(int(e.seconds)), inline_back=True)
            return
        except Exception as e:
            log.warning("sign_in failed: %s", type(e).__name__)
            await cb.answer()
            await self._finish(ctx, T.LOGIN_ERROR, inline_back=True)
            return
        finally:
            code = ""  # noqa: F841  (کد جایی نمی‌مونه)
        await cb.answer()
        await self._success(ctx)

    # ------------------------------------------------------------ مرحله‌ی رمز دومرحله‌ای
    async def submit_password(self, message: Message) -> None:
        uid = message.from_user.id
        # پیام حاوی رمز همیشه فوراً پاک می‌شه
        try:
            await message.delete()
        except TelegramAPIError:
            pass
        ctx = self._ctx.get(uid)
        if ctx is None:
            return
        password = (message.text or "")[:256]
        async with ctx.lock:
            if self._ctx.get(uid) is not ctx or ctx.stage != "password":
                return
            self._touch(ctx)
            try:
                await ctx.client.sign_in(password=password)
            except PasswordHashInvalidError:
                ctx.wrong_passwords += 1
                if ctx.wrong_passwords >= MAX_WRONG_PASSWORDS:
                    await self._finish(ctx, T.PASSWORD_TOO_MANY, inline_back=True)
                    return
                await self._edit(ctx, T.password_prompt(T.PASSWORD_WRONG), K.cancel_only())
                return
            except FloodWaitError as e:
                await self._finish(ctx, T.login_flood(int(e.seconds)), inline_back=True)
                return
            except Exception as e:
                log.warning("password sign_in failed: %s", type(e).__name__)
                await self._finish(ctx, T.LOGIN_ERROR, inline_back=True)
                return
            finally:
                password = ""  # noqa: F841
            await self._success(ctx)

    async def drop_stray(self, message: Message) -> None:
        """کاربر وسط وارد کردن کد توی چت چیزی تایپ کرد: پاکش کن (ممکنه کد باشه)."""
        try:
            await message.delete()
        except TelegramAPIError:
            pass

    # ------------------------------------------------------------ موفقیت
    async def _success(self, ctx: LoginCtx) -> None:
        client = ctx.client
        try:
            session_string = client.session.save()
            async with self.db.begin() as s:
                saved = await save_account(s, ctx.user_id, ctx.phone, session_string, self.vault, utcnow())
        except Exception:
            log.exception("saving account failed")
            await self._finish(ctx, T.LOGIN_ERROR, inline_back=True)
            return
        finally:
            session_string = ""  # noqa: F841
        if not saved:
            await self._finish(ctx, T.LOGIN_SUB_ENDED, inline_back=True)
            return
        # فقط قطع می‌کنیم؛ log_out نمی‌زنیم چون سشن باید معتبر بمونه
        ids, ctx.msg_ids = ctx.msg_ids[:], []
        await self._delete(ctx.chat_id, ids)
        await self._close(ctx)
        try:
            await self.bot.send_message(ctx.chat_id, T.LOGIN_DONE, reply_markup=K.main_menu())
        except TelegramAPIError:
            pass
